"""Reflex Plugin System."""

from . import embed, sitemap, tailwind_v3, tailwind_v4
from ._screenshot import ScreenshotPlugin as _ScreenshotPlugin
from .base import (
    CommonContext,
    Plugin,
    PostBuildContext,
    PostCompileContext,
    PreCompileContext,
    RegisterRouteContext,
    get_plugin,
)
from .compiler import (
    BaseContext,
    CompileContext,
    CompilerHooks,
    ComponentAndChildren,
    PageContext,
    PageDefinition,
)
from .embed import EmbedPlugin
from .sitemap import SitemapPlugin
from .tailwind_v3 import TailwindV3Plugin
from .tailwind_v4 import TailwindV4Plugin

__all__ = [
    "BaseContext",
    "CommonContext",
    "CompileContext",
    "CompilerHooks",
    "ComponentAndChildren",
    "EmbedPlugin",
    "PageContext",
    "PageDefinition",
    "Plugin",
    "PostBuildContext",
    "PostCompileContext",
    "PreCompileContext",
    "RegisterRouteContext",
    "SitemapPlugin",
    "TailwindV3Plugin",
    "TailwindV4Plugin",
    "_ScreenshotPlugin",
    "embed",
    "get_plugin",
    "sitemap",
    "tailwind_v3",
    "tailwind_v4",
]
