"""Stable browser DOM slot names for CSS/Tailwind hooks."""

from __future__ import annotations

from collections.abc import Mapping

CHART_DOM_SLOTS: tuple[str, ...] = (
    "root",
    "title",
    "chrome",
    "canvas",
    "annotation_layer",
    "labels",
    "legend",
    "legend_title",
    "legend_item",
    "legend_swatch",
    "legend_label",
    "colorbar",
    "colorbar_bar",
    "colorbar_extension",
    "colorbar_line",
    "colorbar_tick",
    "colorbar_minor_tick",
    "colorbar_title",
    "tooltip",
    "tooltip_title",
    "tooltip_row",
    "tooltip_label",
    "tooltip_value",
    "modebar",
    "modebar_drag_handle",
    "modebar_control_group",
    "modebar_separator",
    "modebar_button",
    "modebar_icon",
    "modebar_zoom_value",
    "modebar_indicator",
    "modebar_selection_icon",
    "modebar_menu",
    "modebar_menu_separator",
    "modebar_menu_icon",
    "modebar_menu_label",
    "modebar_history_controls",
    "selection",
    "crosshair_x",
    "crosshair_y",
    "badge",
    "badge_item",
    "axis_band",
    "axis_line",
    "tick_mark",
    "tick_label",
    "axis_title",
    "annotation_label",
)
"""Stable `class_names` / chrome `style` slots emitted by the browser client."""


def validate_dom_slots(mapping: Mapping[str, object], label: str) -> None:
    """Reject unknown DOM slots before they reach the standalone/widget spec."""
    unknown = sorted(set(mapping) - set(CHART_DOM_SLOTS))
    if unknown:
        slots = ", ".join(CHART_DOM_SLOTS)
        raise ValueError(f"{label} has unknown slot(s) {unknown}; expected one of: {slots}")
