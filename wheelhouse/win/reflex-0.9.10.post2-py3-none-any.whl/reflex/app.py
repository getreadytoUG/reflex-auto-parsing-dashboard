"""The main Reflex app."""

from __future__ import annotations

import asyncio
import contextlib
import copy
import dataclasses
import functools
import importlib
import inspect
import json
import logging
import operator
import sys
import time
import traceback
import urllib.parse
from collections.abc import (
    AsyncIterator,
    Callable,
    Collection,
    Coroutine,
    Mapping,
    Sequence,
)
from contextvars import Token
from types import SimpleNamespace
from typing import TYPE_CHECKING, Any, overload

from reflex_base import constants
from reflex_base.components.component import Component, ComponentStyle
from reflex_base.config import get_config, reload_config
from reflex_base.context.base import BaseContext
from reflex_base.environment import environment
from reflex_base.event import (
    _EVENT_FIELDS,
    Event,
    EventSpec,
    EventType,
    IndividualEventType,
    noop,
)
from reflex_base.event.context import EventContext
from reflex_base.event.processor import BaseStateEventProcessor, EventProcessor
from reflex_base.registry import RegistrationContext
from reflex_base.telemetry_context import CompileTrigger, TelemetryContext
from reflex_base.utils import memo_paths
from reflex_base.utils.imports import ImportVar
from reflex_base.utils.types import ASGIApp, Message, Receive, Scope, Send
from reflex_components_core.base.error_boundary import ErrorBoundary
from reflex_components_core.base.fragment import Fragment
from reflex_components_core.core.banner import (
    backend_disabled,
    connection_pulser,
    connection_toaster,
)
from reflex_components_core.core.breakpoints import set_breakpoints
from reflex_components_core.core.sticky import sticky
from reflex_components_sonner.toast import toast
from socketio import ASGIApp as EngineIOApp
from socketio import AsyncNamespace, AsyncServer
from starlette.applications import Starlette
from starlette.middleware import cors
from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.staticfiles import StaticFiles
from typing_extensions import Unpack

from reflex._upload import UploadedFilesHeadersMiddleware, upload
from reflex._upload import UploadFile as UploadFile
from reflex.admin import AdminDash
from reflex.app_mixins import AppMixin, LifespanMixin, MiddlewareMixin
from reflex.compiler import compiler
from reflex.compiler.compiler import readable_name_from_component
from reflex.istate.data import RouterData
from reflex.istate.manager import StateManager, StateModificationContext
from reflex.istate.manager.token import BaseStateToken
from reflex.route import (
    get_route_args,
    replace_brackets_with_keywords,
    verify_route_validity,
)
from reflex.state import BaseState, State, StateUpdate, all_base_state_classes
from reflex.utils import (
    codespaces,
    exceptions,
    format,
    js_runtimes,
    prerequisites,
    telemetry_accounting,
)
from reflex.utils.exec import (
    get_backend_compile_trigger,
    get_compile_context,
    is_prod_mode,
    is_testing_env,
    should_prerender_routes,
)
from reflex.utils.misc import run_in_thread
from reflex.utils.token_manager import RedisTokenManager, TokenManager

logger = logging.getLogger(__name__)

if sys.version_info < (3, 13):
    from typing_extensions import deprecated
else:
    from warnings import deprecated

if TYPE_CHECKING:
    from reflex_base.plugins import Plugin
    from reflex_base.plugins.base import AddPageProtocol
    from reflex_base.vars import Var

    # Define custom types.
    ComponentCallable = Callable[[], Component | tuple[Component, ...] | str | Var]
else:
    ComponentCallable = Callable[[], Component | tuple[Component, ...] | str]

Reducer = Callable[[Event], Coroutine[Any, Any, StateUpdate]]


def default_frontend_exception_handler(exception: Exception) -> None:
    """Default frontend exception handler function.

    Args:
        exception: The exception.

    """
    logger.error(f"[Reflex Frontend Exception]\n {exception}\n")


def default_backend_exception_handler(exception: Exception) -> EventSpec:
    """Default backend exception handler function.

    Args:
        exception: The exception.

    Returns:
        EventSpec: The window alert event.

    """
    from reflex_components_sonner.toast import toast

    error = traceback.format_exception(
        type(exception), exception, exception.__traceback__
    )

    logger.error(f"[Reflex Backend Exception]\n {''.join(error)}\n")

    error_message = (
        ["Contact the website administrator."]
        if is_prod_mode()
        else [f"{type(exception).__name__}: {exception}", "See logs for details."]
    )

    return toast(
        "An error occurred.",
        level="error",
        fallback_to_alert=True,
        description="\n".join(error_message),
        position="top-center",
        id="backend_error",
        style={"width": "500px", "white-space": "pre-wrap"},
    )


def _resolve_import_path(import_path: str) -> Any:
    """Resolve a dotted import path to the object it refers to.

    The path is split on the final dot: everything before it is imported as a
    module, and the final segment is read as an attribute of that module
    (``from path_0.path_1... import path[-1]``).

    Args:
        import_path: The dotted import path (e.g. "my_app.components.loading").

    Returns:
        The object referenced by the import path.

    Raises:
        ValueError: If the path has no dot separating the module from the attribute.
    """
    module, _, attribute_name = import_path.rpartition(".")
    if not module:
        msg = (
            f"Invalid import path {import_path!r}: expected a dotted "
            "'module.attribute' path (e.g. 'my_app.components.loading')."
        )
        raise ValueError(msg)
    return getattr(importlib.import_module(module), attribute_name)


def _component_from_import_path(
    import_path: str, feature_name: str
) -> Component | None:
    """Resolve a dotted import path and render its callable into a component.

    The final segment of the path must be a no-arg callable returning a component.

    Args:
        import_path: The dotted import path to the component callable.
        feature_name: The config name to reference in the error message on failure.

    Returns:
        The resolved component, or None if it could not be loaded.
    """
    try:
        component = Fragment.create(_resolve_import_path(import_path)())
        component._get_all_imports()
    except Exception as e:
        from reflex.compiler.utils import save_error

        log_path = save_error(e)

        logger.error(
            f"Error loading {feature_name} {import_path}. Error saved to {log_path}"
        )
        return None

    return component


def extra_overlay_function() -> Component | None:
    """Extra overlay function to add to the overlay component.

    Returns:
        The extra overlay function.
    """
    extra_config = get_config().extra_overlay_function
    if extra_config:
        return _component_from_import_path(extra_config, "extra_overlay_function")
    return None


def default_overlay_component() -> Component:
    """Default overlay component included in the app wraps.

    Returns:
        The default overlay component, which is a connection banner/toaster set.
    """
    from reflex_base.components.memo import memo

    def default_overlay_components() -> Component:
        return Fragment.create(
            connection_pulser(),
            connection_toaster(),
            *(
                [backend_disabled()]
                if get_compile_context() == constants.CompileContext.DEPLOY
                else []
            ),
            *codespaces.codespaces_auto_redirect(),
        )

    return Fragment.create(memo(default_overlay_components)())


def default_error_boundary(*children: Component, **props) -> Component:
    """Default error_boundary attribute for App.

    Args:
        *children: The children to render in the error boundary.
        **props: The props to pass to the error boundary.

    Returns:
        The default error_boundary, which is an ErrorBoundary.

    """
    return ErrorBoundary.create(
        *children,
        **props,
    )


@dataclasses.dataclass(
    frozen=True,
)
class UnevaluatedPage:
    """An uncompiled page."""

    component: Component | ComponentCallable
    route: str
    title: Var | str | None = None
    description: Var | str | None = None
    image: str = ""
    on_load: EventType[()] | None = None
    meta: Sequence[Mapping[str, Any] | Component] = ()
    context: Mapping[str, Any] = dataclasses.field(default_factory=dict)
    _source_module: str | None = None

    def merged_with(self, other: UnevaluatedPage) -> UnevaluatedPage:
        """Merge the other page into this one.

        Args:
            other: The other page to merge with.

        Returns:
            The merged page.
        """
        return dataclasses.replace(
            self,
            title=self.title if self.title is not None else other.title,
            description=self.description
            if self.description is not None
            else other.description,
            on_load=self.on_load if self.on_load is not None else other.on_load,
            context=self.context if self.context is not None else other.context,
            _source_module=self._source_module
            if self._source_module is not None
            else other._source_module,
        )


@dataclasses.dataclass(frozen=True)
class _PreparedPage:
    """A validated page descriptor awaiting registration."""

    page: UnevaluatedPage
    route_args: dict[str, str]


def _route_arg_label(arg_type: str) -> str:
    """Return the human-readable label for a dynamic route argument type.

    Args:
        arg_type: The ``RouteArgType`` value.

    Returns:
        ``"list"`` for catch-all arguments, otherwise ``"single"``.
    """
    return "list" if arg_type == constants.RouteArgType.LIST else "single"


@dataclasses.dataclass()
class App(MiddlewareMixin, LifespanMixin):
    """The main Reflex app that encapsulates the backend and frontend.

    Every Reflex app needs an app defined in its main module.

    ```python
    # app.py
    import reflex as rx

    # Define state and pages
    ...

    app = rx.App(
        # Set global level style.
        style={...},
        # Deprecated legacy shortcut for the Radix Themes plugin.
        theme=rx.theme(accent_color="blue"),
    )
    ```

    Attributes:
        theme: Deprecated legacy shortcut for configuring the app-level Radix [theme](https://reflex.dev/docs/styling/theming/).
        style: The [global style](https://reflex.dev/docs/styling/overview/#global-styles) for the app.
        stylesheets: A list of URLs to [stylesheets](https://reflex.dev/docs/styling/custom-stylesheets/) to include in the app.
        reset_style: Whether to include CSS reset for margin and padding. Defaults to True.
        app_wraps: App wraps to be applied to the whole app. Expected to be a dictionary of (order, name) to a function that takes whether the state is enabled and optionally returns a component.
        extra_app_wraps: Extra app wraps to be applied to the whole app.
        head_components: Components to add to the head of every page.
        sio: The Socket.IO AsyncServer instance.
        html_lang: The language to add to the html root tag of every page.
        html_custom_attrs: Attributes to add to the html root tag of every page.
        enable_state: Whether to enable [state](https://reflex.dev/docs/state/overview/) for the app. If False, the app will not use state.
        admin_dash: Admin dashboard to view and manage the database.
        frontend_exception_handler: Frontend [error handler](https://reflex.dev/docs/utility-methods/exception-handlers/) function.
        backend_exception_handler: Backend [error handler](https://reflex.dev/docs/utility-methods/exception-handlers/) function.
        toaster: Put the [toast](https://reflex.dev/docs/library/overlay/toast/) provider in the app wrap.
        api_transformer: One or more transforms applied to the backend ASGI app before it runs — mount a FastAPI/Starlette app or wrap it in ASGI middleware. See the [API Transformer docs](https://reflex.dev/docs/api-routes/overview/) for examples.
    """

    theme: Component | None = dataclasses.field(default=None)

    style: ComponentStyle = dataclasses.field(default_factory=dict)

    stylesheets: list[str] = dataclasses.field(default_factory=list)

    reset_style: bool = dataclasses.field(default=True)

    app_wraps: dict[tuple[int, str], Callable[[bool], Component | None]] = (
        dataclasses.field(
            default_factory=lambda: {
                (55, "ErrorBoundary"): (
                    lambda stateful: default_error_boundary(
                        **({"on_error": noop()} if not stateful else {})
                    )
                ),
                (5, "Overlay"): (
                    lambda stateful: default_overlay_component() if stateful else None
                ),
                (4, "ExtraOverlay"): lambda stateful: extra_overlay_function(),
            }
        )
    )

    extra_app_wraps: dict[tuple[int, str], Callable[[bool], Component | None]] = (
        dataclasses.field(default_factory=dict)
    )

    head_components: list[Component] = dataclasses.field(default_factory=list)

    sio: AsyncServer | None = None

    html_lang: str | None = None

    html_custom_attrs: dict[str, str] | None = None

    # A map from a route to an unevaluated page.
    _unevaluated_pages: dict[str, UnevaluatedPage] = dataclasses.field(
        default_factory=dict
    )

    # Whether the plugins' ``register_route`` hooks have run for this app.
    _plugin_routes_registered: bool = False

    # A map from a page route to the component to render. Users should use `add_page`.
    _pages: dict[str, Component] = dataclasses.field(default_factory=dict)

    # A mapping of pages which created states as they were being evaluated.
    _stateful_pages: dict[str, None] = dataclasses.field(default_factory=dict)

    # Routes whose page function has already been evaluated in this process.
    # Evaluating a page has global side effects (e.g. ComponentState.create
    # registers dynamic state classes), so a route must not be evaluated twice
    # in one process. A forked prod worker inherits this set from the parent
    # that already compiled and skips re-evaluation.
    _evaluated_pages: set[str] = dataclasses.field(default_factory=set)

    # The backend API object.
    _api: Starlette | None = None

    # The state class to use for the app.
    _state: type[BaseState] | None = None

    enable_state: bool = True

    # Class to manage many client states.
    _state_manager: StateManager | None = None

    # Mapping from a route to event handlers to trigger when the page loads.
    _load_events: dict[str, list[IndividualEventType[()]]] = dataclasses.field(
        default_factory=dict
    )

    admin_dash: AdminDash | None = None

    # The async server name space.
    _event_namespace: EventNamespace | None = None

    # The processor queue for handling events.
    _event_processor: EventProcessor | None = None

    # Store the RegistrationContext to apply inside the ASGI callable task.
    _registration_context: RegistrationContext = dataclasses.field(
        default_factory=RegistrationContext.ensure_context
    )

    frontend_exception_handler: Callable[[Exception], None] = (
        default_frontend_exception_handler
    )

    backend_exception_handler: Callable[
        [Exception], EventSpec | list[EventSpec] | None
    ] = default_backend_exception_handler

    toaster: Component | None = dataclasses.field(default_factory=toast.provider)

    hydrate_fallback: Component | ComponentCallable | None = None

    api_transformer: (
        Sequence[Callable[[ASGIApp], ASGIApp] | Starlette]
        | Callable[[ASGIApp], ASGIApp]
        | Starlette
        | None
    ) = None

    @property
    def event_namespace(self) -> EventNamespace | None:
        """The event namespace.

        Returns:
            The event namespace.
        """
        return self._event_namespace

    @property
    def event_processor(self) -> EventProcessor:
        """The event processor.

        Raises:
            RuntimeError: If the event processor is not initialized.
        """
        if self._event_processor is None:
            msg = "Event processor is not initialized."
            raise RuntimeError(msg)
        return self._event_processor

    def __post_init__(self):
        """Initialize the app.

        Raises:
            ValueError: If the event namespace is not provided in the config.
                        Also, if there are multiple client subclasses of rx.BaseState(Subclasses of rx.BaseState should consist
                        of the DefaultState and the client app state).
        """
        # Special case to allow test cases have multiple subclasses of rx.BaseState.
        if not is_testing_env() and BaseState.__subclasses__() != [State]:
            # Only rx.State is allowed as Base State subclass.
            msg = "rx.BaseState cannot be subclassed directly. Use rx.State instead"
            raise ValueError(msg)

        self._registration_context._set_app(self)

        reload_config()

        if "breakpoints" in self.style:
            set_breakpoints(self.style.pop("breakpoints"))

        # Set up the API.
        self._api = Starlette()
        App._add_cors(self._api)
        self._add_default_endpoints()

        for clz in App.__mro__:
            if clz == App:
                continue
            if issubclass(clz, AppMixin):
                clz._init_mixin(self)

        if self.enable_state:
            self._enable_state()

        # Set up the admin dash.
        self._setup_admin_dash()

        if sys.platform == "win32" and not is_prod_mode():
            # Hack to fix Windows hot reload issue.
            from reflex.utils.compat import windows_hot_reload_lifespan_hack

            self.register_lifespan_task(windows_hot_reload_lifespan_hack)

    def _enable_state(self) -> None:
        """Enable state for the app."""
        if not self._state:
            self._state = State
        self._setup_state()

    def _setup_state(self) -> None:
        """Set up the state for the app.

        Raises:
            RuntimeError: If the socket server is invalid.
        """
        if not self._state:
            return

        config = get_config()

        # Set up the state manager.
        self._state_manager = StateManager.create()

        # Set up the Socket.IO AsyncServer.
        if not self.sio:
            self.sio = AsyncServer(
                async_mode="asgi",
                cors_allowed_origins=(
                    (
                        "*"
                        if config.cors_allowed_origins == ("*",)
                        else list(config.cors_allowed_origins)
                    )
                    if config.transport == "websocket"
                    else []
                ),
                cors_credentials=config.transport == "websocket",
                max_http_buffer_size=environment.REFLEX_SOCKET_MAX_HTTP_BUFFER_SIZE.get(),
                ping_interval=environment.REFLEX_SOCKET_INTERVAL.get(),
                ping_timeout=environment.REFLEX_SOCKET_TIMEOUT.get(),
                json=SimpleNamespace(
                    dumps=staticmethod(format.json_dumps),
                    loads=staticmethod(json.loads),
                ),
                allow_upgrades=False,
                transports=[config.transport],
            )
        elif getattr(self.sio, "async_mode", "") != "asgi":
            msg = f"Custom `sio` must use `async_mode='asgi'`, not '{self.sio.async_mode}'."
            raise RuntimeError(msg)

        # Create the socket app. Note event endpoint constant replaces the default 'socket.io' path.
        socket_app = EngineIOApp(self.sio, socketio_path="")
        namespace = config.get_event_namespace()

        # Create the event namespace and attach the main app. Not related to any paths.
        self._event_namespace = EventNamespace(namespace, self)

        # Register the event namespace with the socket.
        self.sio.register_namespace(self.event_namespace)
        # Mount the socket app with the API.
        if self._api:

            class HeaderMiddleware:
                def __init__(self, app: ASGIApp):
                    self.app = app

                async def __call__(self, scope: Scope, receive: Receive, send: Send):
                    original_send = send

                    async def modified_send(message: Message):
                        if message["type"] == "websocket.accept":
                            if scope.get("subprotocols"):
                                # The following *does* say "subprotocol" instead of "subprotocols", intentionally.
                                message["subprotocol"] = scope["subprotocols"][0]

                            headers = dict(message.get("headers", []))
                            header_key = b"sec-websocket-protocol"
                            if subprotocol := headers.get(header_key):
                                message["headers"] = [
                                    *message.get("headers", []),
                                    (header_key, subprotocol),
                                ]

                        return await original_send(message)

                    return await self.app(scope, receive, modified_send)

            socket_app_with_headers = HeaderMiddleware(socket_app)
            self._api.mount(
                config.prepend_backend_path(str(constants.Endpoint.EVENT)),
                socket_app_with_headers,
            )

        # Check the exception handlers
        self._validate_exception_handlers()

        # Ensure the event processor starts and stops with the server.
        self.register_lifespan_task(self._setup_event_processor)

    def _set_contexts_internal(self) -> dict[type[BaseContext], Token]:
        """Set Reflex contexts if not already present, returning reset tokens.

        Returns:
            A dict mapping context class to the contextvars Token for each
            context that was set. Empty if all contexts were already present.
        """
        tokens: dict[type[BaseContext], Token] = {}

        if self._registration_context is not None:
            try:
                RegistrationContext.get()
            except LookupError:
                tokens[RegistrationContext] = RegistrationContext.set(
                    self._registration_context
                )

        if (
            self._event_processor is not None
            and self._event_processor._root_context is not None
        ):
            try:
                EventContext.get()
            except LookupError:
                tokens[EventContext] = EventContext.set(
                    self._event_processor._root_context
                )

        return tokens

    def set_contexts(self) -> contextlib.AbstractContextManager:
        """Set Reflex contexts needed for state and event processing.

        Pushes RegistrationContext and EventContext into the current
        contextvars scope, but only if they are not already set.

        Can be used as a context manager::

            with app.set_contexts():
                async with app.modify_state(token) as state:
                    ...

        Returns:
            A context manager that resets any contexts that were set on exit.
        """
        tokens = self._set_contexts_internal()
        if not tokens:
            return contextlib.nullcontext()
        stack = contextlib.ExitStack()
        for ctx_cls, tok in tokens.items():
            stack.callback(ctx_cls.reset, tok)
        return stack

    def _context_middleware(self, app: ASGIApp) -> ASGIApp:
        """Ensure Reflex contexts are attached for each ASGI request.

        Many ASGI servers start each request with a fresh contextvars scope,
        so this middleware re-applies the RegistrationContext and EventContext
        that are needed for Reflex state and event processing.

        Args:
            app: The ASGI app to attach the middleware to.

        Returns:
            The ASGI app with the middleware attached.
        """

        async def context_middleware(scope: Scope, receive: Receive, send: Send):
            self._set_contexts_internal()
            await app(scope, receive, send)

        return context_middleware

    @contextlib.asynccontextmanager
    async def _setup_event_processor(self) -> AsyncIterator[None]:
        # Create the event processor.
        self._event_processor = BaseStateEventProcessor(
            middleware=self, backend_exception_handler=self.backend_exception_handler
        )
        async with self._event_processor.configure(
            state_manager=self.state_manager,
            event_namespace=self.event_namespace,
        ):
            yield

    def __repr__(self) -> str:
        """Get the string representation of the app.

        Returns:
            The string representation of the app.
        """
        return f"<App state={self._state.__name__ if self._state else None}>"

    def __call__(self) -> ASGIApp:
        """Run the backend api instance.

        Returns:
            The backend api.

        Raises:
            ValueError: If the app has not been initialized.
        """
        from reflex_base.vars.base import GLOBAL_CACHE

        from reflex.assets import remove_stale_external_asset_symlinks

        # Clean up stale symlinks in assets/external/ before compiling, so that
        # rx.asset(shared=True) symlink re-creation doesn't trigger further reloads.
        remove_stale_external_asset_symlinks()

        trigger = get_backend_compile_trigger()
        self._compile(
            prerender_routes=should_prerender_routes(),
            trigger=trigger,
        )

        # In preview mode the frontend is served as a mounted static bundle rather
        # than by the Vite dev server, so each hot reload must re-run the frontend
        # build against the freshly compiled output.
        if (
            trigger == "hot_reload"
            and environment.REFLEX_ENV_MODE.get() == constants.Env.PREVIEW
            and environment.REFLEX_MOUNT_FRONTEND_COMPILED_APP.get()
        ):
            from reflex.utils import build

            # The previous output is deleted before building, so a failed build
            # must fail hard rather than pretend to serve a frontend.
            build.build()

        config = get_config()

        for plugin in config.plugins:
            plugin.post_compile(app=self)

        # We will not be making more vars, so we can clear the global cache to free up memory.
        GLOBAL_CACHE.clear()

        if not self._api:
            msg = "The app has not been initialized."
            raise ValueError(msg)

        asgi_app = self._api

        if environment.REFLEX_MOUNT_FRONTEND_COMPILED_APP.get():
            from reflex.utils.exec import get_frontend_mount

            asgi_app.routes.append(get_frontend_mount())

        if self.api_transformer is not None:
            api_transformers: Sequence[Starlette | Callable[[ASGIApp], ASGIApp]] = (
                [self.api_transformer]
                if not isinstance(self.api_transformer, Sequence)
                else self.api_transformer
            )

            for api_transformer in api_transformers:
                if isinstance(api_transformer, Starlette):
                    # Mount the api to the starlette app.
                    App._add_cors(api_transformer)
                    api_transformer.mount("", asgi_app)
                    asgi_app = api_transformer
                else:
                    # Transform the asgi app.
                    asgi_app = api_transformer(asgi_app)

        top_asgi_app = Starlette(lifespan=self._run_lifespan_tasks)
        # Make sure Reflex contexts are attached for each request.
        top_asgi_app.mount(
            "",
            self._context_middleware(asgi_app),
        )
        App._add_cors(top_asgi_app)
        return top_asgi_app

    def _add_default_endpoints(self):
        """Add default api endpoints (ping)."""
        # To test the server.
        if not self._api:
            return

        config = get_config()
        self._api.add_route(
            config.prepend_backend_path(str(constants.Endpoint.PING)),
            ping,
            methods=["GET"],
        )
        self._api.add_route(
            config.prepend_backend_path(str(constants.Endpoint.HEALTH)),
            health,
            methods=["GET"],
        )

    def _add_optional_endpoints(self):
        """Add optional api endpoints (_upload)."""
        from reflex_components_core.core.upload import Upload, get_upload_dir

        if not self._api:
            return
        config = get_config()
        upload_is_used_marker = (
            prerequisites.get_backend_dir() / constants.Dirs.UPLOAD_IS_USED
        )
        if Upload.is_used or upload_is_used_marker.exists():
            # To upload files.
            self._api.add_route(
                config.prepend_backend_path(str(constants.Endpoint.UPLOAD)),
                upload(self),
                methods=["POST"],
            )

            # To access uploaded files.
            self._api.mount(
                config.prepend_backend_path(str(constants.Endpoint.UPLOAD)),
                UploadedFilesHeadersMiddleware(StaticFiles(directory=get_upload_dir())),
                name="uploaded_files",
            )

            upload_is_used_marker.parent.mkdir(parents=True, exist_ok=True)
            upload_is_used_marker.touch()
        if codespaces.is_running_in_codespaces():
            self._api.add_route(
                config.prepend_backend_path(str(constants.Endpoint.AUTH_CODESPACE)),
                codespaces.auth_codespace,
                methods=["GET"],
            )
        if environment.REFLEX_ADD_ALL_ROUTES_ENDPOINT.get():
            self.add_all_routes_endpoint()

    @staticmethod
    def _add_cors(api: Starlette):
        """Add CORS middleware to the app.

        Args:
            api: The Starlette app to add CORS middleware to.
        """
        api.add_middleware(
            cors.CORSMiddleware,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
            allow_origins=get_config().cors_allowed_origins,
        )

    @property
    def state_manager(self) -> StateManager:
        """The state manager.

        Returns:
            The initialized state manager.

        Raises:
            ValueError: if the state has not been initialized.
        """
        if self._state_manager is None:
            msg = "The state manager has not been initialized."
            raise ValueError(msg)
        return self._state_manager

    @staticmethod
    def _generate_component(component: Component | ComponentCallable) -> Component:
        """Generate a component from a callable.

        Args:
            component: The component function to call or Component to return as-is.

        Returns:
            The generated component.
        """
        from reflex.compiler.compiler import into_component

        return into_component(component)

    @staticmethod
    def _page_route_key(
        component: Component | ComponentCallable | None, route: str | None
    ) -> str | None:
        """Derive the normalized route used to register a page.

        Args:
            component: The page component or component callable.
            route: The explicit route, if any.

        Returns:
            The normalized route, or ``None`` when no route can be derived.
        """
        if route is not None:
            return format.format_route(route)
        if isinstance(component, Callable):
            return format.format_route(format.to_kebab_case(component.__name__))
        return None

    def add_page(
        self,
        component: Component | ComponentCallable | None = None,
        route: str | None = None,
        title: str | Var | None = None,
        description: str | Var | None = None,
        image: str = constants.DefaultPage.IMAGE,
        on_load: EventType[()] | None = None,
        meta: Sequence[Mapping[str, Any] | Component] = constants.DefaultPage.META_LIST,
        context: dict[str, Any] | None = None,
    ):
        """Add a page to the app.

        If the component is a callable, by default the route is the name of the
        function. Otherwise, a route must be provided.

        Args:
            component: The component to display at the page.
            route: The route to display the component at.
            title: The title of the page.
            description: The description of the page.
            image: The image to display on the page.
            on_load: The event handler(s) that will be called each time the page load.
            meta: The metadata of the page.
            context: Values passed to page for custom page-specific logic.

        Raises:
            PageValueError: When the component is not set for a non-404 page.
            RouteValueError: When the specified route name already exists.
            ValueError: When the route syntax is invalid.
        """
        self._register_prepared_page(
            self._prepare_page(
                component,
                route,
                title,
                description,
                image,
                on_load,
                meta,
                context,
            )
        )

    def _prepare_page(
        self,
        component: Component | ComponentCallable | None = None,
        route: str | None = None,
        title: str | Var | None = None,
        description: str | Var | None = None,
        image: str = constants.DefaultPage.IMAGE,
        on_load: EventType[()] | None = None,
        meta: Sequence[Mapping[str, Any] | Component] = constants.DefaultPage.META_LIST,
        context: dict[str, Any] | None = None,
    ) -> _PreparedPage:
        """Validate and normalize a page without mutating app route state.

        App subclasses that extend ``add_page`` arguments should perform their
        pure argument normalization here so staged plugin contributions and
        direct page registration share the same preparation path.

        Args:
            component: The component to display at the page.
            route: The route to display the component at.
            title: The title of the page.
            description: The description of the page.
            image: The image to display on the page.
            on_load: The event handler(s) called each time the page loads.
            meta: The metadata of the page.
            context: Values passed to page for custom page-specific logic.

        Returns:
            The validated page descriptor and its dynamic route arguments.

        Raises:
            PageValueError: When the component is not set for a non-404 page.
            RouteValueError: When a route cannot be derived.
            ValueError: When the route syntax is invalid.
        """
        route = self._page_route_key(component, route)
        if route is None:
            msg = "Route must be set if component is not a callable."
            raise exceptions.RouteValueError(msg)

        if route == constants.Page404.SLUG:
            if component is None:
                from reflex_components_core.el.elements import span

                component = span("404: Page not found")
            title = title or constants.Page404.TITLE
            description = description or constants.Page404.DESCRIPTION
            image = image or constants.Page404.IMAGE
        else:
            if component is None:
                msg = "Component must be set for a non-404 page."
                raise exceptions.PageValueError(msg)

        # Check if the route given is valid
        verify_route_validity(route)

        if isinstance(component, Callable):
            source_module = memo_paths.capture_source_module(component)
        else:
            # The user passed a pre-built Component instance — fall back to
            # walking the call stack from add_page's caller.
            source_module = memo_paths.resolve_user_module_from_frame(skip=1)

        unevaluated_page = UnevaluatedPage(
            component=component,
            route=route,
            title=title,
            description=description,
            image=image,
            on_load=on_load,
            meta=meta,
            context=context or {},
            _source_module=source_module,
        )

        return _PreparedPage(
            page=unevaluated_page,
            route_args=get_route_args(route),
        )

    def _register_prepared_page(self, prepared: _PreparedPage) -> None:
        """Resolve conflicts and commit one directly added page.

        Args:
            prepared: The validated page descriptor to register.

        Raises:
            RouteValueError: When another component already owns the route.
        """
        page = prepared.page
        if page.route in self._unevaluated_pages:
            existing_page = self._unevaluated_pages[page.route]
            if existing_page.component is page.component:
                prepared = dataclasses.replace(
                    prepared,
                    page=page.merged_with(existing_page),
                )
                logger.warning(
                    f"Page {page.route} is being redefined with the same component."
                )
            else:
                route_name = (
                    f"`{page.route}` or `/`"
                    if page.route == constants.PageNames.INDEX_ROUTE
                    else f"`{page.route}`"
                )
                msg = (
                    f"Tried to add page {readable_name_from_component(page.component)} with route {route_name} but "
                    f"page {readable_name_from_component(existing_page.component)} with the same route already exists. "
                    "Make sure you do not have two pages with the same route."
                )
                raise exceptions.RouteValueError(msg)
        self._commit_page(prepared)

    def _commit_page(
        self, prepared: _PreparedPage, *, setup_dynamic_args: bool = True
    ) -> None:
        """Commit a prepared page to the app.

        This is the fixed, non-fallible final write. Staged plugin batches
        invoke this framework implementation directly so an override cannot
        make the batch partially commit — subclasses must customize page
        registration in ``_prepare_page``, not here.

        Args:
            prepared: The validated page descriptor to register.
            setup_dynamic_args: Whether to install its dynamic route variables.
                A staged plugin batch installs all variables once before
                committing its descriptors.
        """
        page = prepared.page
        if setup_dynamic_args:
            # This state assignment is only required for tests using the
            # deprecated state kwarg for App.
            state = self._state or State
            state.setup_dynamic_args(prepared.route_args)

        self._load_events[page.route] = (
            (page.on_load if isinstance(page.on_load, list) else [page.on_load])
            if page.on_load is not None
            else []
        )

        self._unevaluated_pages[page.route] = page
        self.__dict__.pop("router", None)

    def _register_plugin_pages(self, plugins: Sequence[Plugin]) -> None:
        """Collect and commit plugin page contributions, once per app instance.

        Hooks receive a staged ``add_page`` capability. No live app route
        state is mutated until every hook succeeds, so a hook exception cannot
        leave partial routes or dynamic route variables behind.

        Args:
            plugins: The active plugins, in configuration order.
        """
        if self._plugin_routes_registered:
            return

        # Snapshot preserving definition order for deterministic error messages.
        app_routes = dict.fromkeys(self._unevaluated_pages)
        contributions: list[_PreparedPage] = []
        route_owners: dict[str, str] = {}

        def has_app_page(route: str) -> bool:
            """Return whether the app defines a normalized route.

            Args:
                route: The route to check.

            Returns:
                Whether the route belongs to the app rather than a plugin.
            """
            return format.format_route(route) in app_routes

        def make_add_page(plugin_name: str) -> AddPageProtocol:
            """Create a staged page registrar bound to one plugin.

            Args:
                plugin_name: Name identifying the contributing plugin.

            Returns:
                A registrar recording contributions under ``plugin_name``.
            """

            def add_page(
                component: Component | ComponentCallable | None = None,
                route: str | None = None,
                **page_args: Any,
            ) -> None:
                """Stage a page contribution owned by the active plugin.

                Args:
                    component: The component or component callable to register.
                    route: The explicit page route, if any.
                    page_args: Additional keyword page-preparation arguments.

                Raises:
                    RouteValueError: If a route cannot be derived or is
                        already owned.
                """
                prepared = self._prepare_page(component, route, **page_args)
                route_key = prepared.page.route

                if route_key in app_routes:
                    msg = (
                        f"Plugin {plugin_name} tried to register route "
                        f"`{route_key}`, but that route is already defined by "
                        "the app; use has_app_page(route) to keep the "
                        "app-defined page."
                    )
                    raise exceptions.RouteValueError(msg)

                if (owner := route_owners.get(route_key)) is not None:
                    msg = (
                        f"Plugin {plugin_name} tried to register route "
                        f"`{route_key}`, but that route is already defined by "
                        f"plugin {owner}; a route can only be registered by "
                        "one plugin."
                    )
                    raise exceptions.RouteValueError(msg)

                existing_routes = app_routes.keys() | route_owners.keys()
                if conflict := self._find_route_conflict(existing_routes, route_key):
                    existing_route, existing_segment, new_segment = conflict
                    existing_owner = (
                        "the app"
                        if existing_route in app_routes
                        else f"plugin {route_owners[existing_route]}"
                    )
                    msg = (
                        f"Plugin {plugin_name} tried to register route "
                        f"`{route_key}`, but it conflicts with route "
                        f"`{existing_route}` defined by {existing_owner}; "
                        "dynamic segment names must match "
                        f"(`{existing_segment}` != `{new_segment}`)."
                    )
                    raise exceptions.RouteValueError(msg)

                route_owners[route_key] = plugin_name
                contributions.append(prepared)

            return add_page

        class_names = [type(plugin).__name__ for plugin in plugins]
        duplicated = {name for name in class_names if class_names.count(name) > 1}
        for index, (plugin, class_name) in enumerate(
            zip(plugins, class_names, strict=True)
        ):
            plugin_name = (
                f"{class_name} (plugins[{index}])"
                if class_name in duplicated
                else class_name
            )
            plugin.register_route(
                app_type=type(self),
                add_page=make_add_page(plugin_name),
                has_app_page=has_app_page,
            )

        # This state assignment is only required for tests using the
        # deprecated state kwarg for App.
        state = self._state or State
        staged_args: dict[str, str] = {}
        # First recorded source of each dynamic argument wins: stale variables
        # from an earlier app in this process, then app routes, then staged
        # contributions in commit order.
        arg_sources: dict[str, tuple[str, str]] = {
            name: (arg_type, "an earlier app in this process (restart to clear it)")
            for name, arg_type in state._dynamic_route_arg_types().items()
        }
        for route in app_routes:
            for name, arg_type in get_route_args(route).items():
                arg_sources.setdefault(
                    name, (arg_type, f"route `{route}` defined by the app")
                )
        for prepared in contributions:
            route = prepared.page.route
            owner = route_owners[route]
            for name, arg_type in prepared.route_args.items():
                existing_type, source = arg_sources.setdefault(
                    name, (arg_type, f"route `{route}` defined by plugin {owner}")
                )
                if existing_type != arg_type:
                    msg = (
                        f"Plugin {owner} tried to register route `{route}` with "
                        f"dynamic argument `{name}` of type "
                        f"`{_route_arg_label(arg_type)}`, but {source} already "
                        f"uses it as type `{_route_arg_label(existing_type)}`. "
                        "Dynamic argument types must be consistent across routes."
                    )
                    raise exceptions.RouteValueError(msg)
                staged_args.setdefault(name, arg_type)
        if staged_args:
            state.setup_dynamic_args(staged_args)

        # Commit through the framework implementation: concrete App extensions
        # normalize extra arguments in ``_prepare_page``; the final writes are
        # intentionally fixed and non-fallible so the batch cannot partially
        # commit.
        for prepared in contributions:
            App._commit_page(self, prepared, setup_dynamic_args=False)

        self._plugin_routes_registered = True

    def _compile_page(self, route: str, save_page: bool = True):
        """Compile a page.

        Args:
            route: The route of the page to compile.
            save_page: If True, the compiled page is saved to self._pages.
        """
        # Evaluating a page has global side effects (dynamic state creation), so
        # skip routes already evaluated in this process to avoid duplicating them.
        # Only skip when there is nothing left to do: the caller does not want the
        # page saved, or it is already saved. Otherwise fall through to build and
        # store the component so ``save_page=True`` still populates ``_pages``.
        if route in self._evaluated_pages and (not save_page or route in self._pages):
            return

        n_states_before = len(all_base_state_classes)
        component = compiler.compile_unevaluated_page(
            route,
            self._unevaluated_pages[route],
            self.style,
            self.theme,
        )

        # Indicate that evaluating this page creates one or more state classes.
        if len(all_base_state_classes) > n_states_before:
            self._stateful_pages[route] = None

        self._evaluated_pages.add(route)

        # Add the page.
        self._check_routes_conflict(route)
        if save_page:
            self._pages[route] = component

    @functools.cached_property
    def router(self) -> Callable[[str], str | None]:
        """The route computer function.

        Returns:
            The route computer function.
        """
        from reflex.route import get_router

        return get_router(list(dict.fromkeys([*self._unevaluated_pages, *self._pages])))

    def get_load_events(self, path: str) -> list[IndividualEventType[()]]:
        """Get the load events for a route.

        Args:
            path: The route to get the load events for.

        Returns:
            The load events for the route.
        """
        four_oh_four_load_events = self._load_events.get("404", [])
        route = self.router(path)
        if not route:
            # If the path is not a valid route, return the 404 page load events.
            return four_oh_four_load_events
        return self._load_events.get(
            route,
            four_oh_four_load_events,
        )

    def _check_routes_conflict(self, new_route: str):
        """Verify if there is any conflict between the new route and any existing route.

        Based on conflicts that React Router would throw if not intercepted.

        Args:
            new_route: the route being newly added.

        Raises:
            RouteValueError: exception showing which conflict exist with the route to be added
        """
        from reflex_base.utils.exceptions import RouteValueError

        conflict = self._find_route_conflict(self._pages, new_route)
        if conflict is not None:
            route, existing_segment, new_segment = conflict
            msg = (
                "You cannot use different slug names for the same dynamic path "
                f"in  {route} and {new_route} "
                f"('{existing_segment}' != '{new_segment}')"
            )
            raise RouteValueError(msg)

    @staticmethod
    def _find_route_conflict(
        existing_routes: Collection[str], new_route: str
    ) -> tuple[str, str, str] | None:
        """Find an existing route with incompatible dynamic segment names.

        Args:
            existing_routes: Routes already occupying the router tree.
            new_route: The route being added.

        Returns:
            The conflicting route and differing segment names, or ``None``.
        """
        if "[" not in new_route:
            return None

        segments = (
            constants.RouteRegex.SINGLE_SEGMENT,
            constants.RouteRegex.DOUBLE_SEGMENT,
            constants.RouteRegex.DOUBLE_CATCHALL_SEGMENT,
        )
        replaced_new_route = replace_brackets_with_keywords(new_route)
        for route in existing_routes:
            replaced_route = replace_brackets_with_keywords(route)
            for rw, nrw, r, nr in zip(
                replaced_route.split("/"),
                replaced_new_route.split("/"),
                route.split("/"),
                new_route.split("/"),
                strict=False,
            ):
                if r == nr:
                    continue
                if rw in segments and nrw in segments:
                    # Two dynamic segments with different names cannot share
                    # the same position in the route tree.
                    return route, r, nr
                # A static segment differing from the other route's segment
                # (static or dynamic) splits into its own subtree, so the rest
                # of the route cannot conflict. e.g. /posts/[id]/info/[slug1]
                # and /posts/[id]/info1/[slug1] is always going to be valid
                # since info1 will break away into its own tree; likewise
                # /posts/all is a legal static sibling of /posts/[id].
                break
        return None

    def _setup_admin_dash(self):
        """Setup the admin dash."""
        try:
            from starlette_admin.contrib.sqla.admin import Admin
            from starlette_admin.contrib.sqla.view import ModelView

            from reflex.model import get_engine
        except ImportError:
            return

        # Get the admin dash.
        if not self._api:
            return

        admin_dash = self.admin_dash

        if admin_dash and admin_dash.models:
            # Build the admin dashboard
            admin = admin_dash.admin or Admin(
                engine=get_engine(),
                title="Reflex Admin Dashboard",
                logo_url="https://reflex.dev/Reflex.svg",
            )

            for model in admin_dash.models:
                view = admin_dash.view_overrides.get(model, ModelView)
                admin.add_view(view(model))

            admin.mount_to(self._api)

    def _get_frontend_packages(
        self,
        imports: Mapping[str, Collection[ImportVar]],
    ) -> None:
        """Gets the frontend packages to be installed and filters out the unnecessary ones.

        Args:
            imports: A dictionary containing the imports used in the current page.

        Example:
            >>> _get_frontend_packages({"react": "16.14.0", "react-dom": "16.14.0"})
        """
        dependencies = constants.PackageJson.DEPENDENCIES
        dev_dependencies = constants.PackageJson.DEV_DEPENDENCIES
        page_imports = {
            package_name
            for import_name, tags in imports.items()
            if (package_name := self._get_frontend_package_name(import_name))
            and package_name not in dependencies
            and package_name not in dev_dependencies
            and any(tag.install for tag in tags)
        }
        pinned = {i.rpartition("@")[0] for i in page_imports if "@" in i}
        page_imports = {i for i in page_imports if i not in pinned}

        frontend_packages = get_config().frontend_packages
        filtered_frontend_packages = []
        for package in frontend_packages:
            if package in page_imports:
                logger.warning(
                    f"React packages and their dependencies are inferred from Component.library and Component.lib_dependencies, remove `{package}` from `frontend_packages`"
                )
                continue
            filtered_frontend_packages.append(package)
        page_imports.update(filtered_frontend_packages)
        js_runtimes.install_frontend_packages(page_imports, get_config())

    @staticmethod
    def _get_frontend_package_name(import_name: str) -> str | None:
        """Resolve the npm package name to install for a library import path.

        Args:
            import_name: The import path key used in component imports.

        Returns:
            The package name that should be installed, including pinned version when
            available, or None when the import does not represent an installable npm package.
        """
        if import_name == "" or any(
            import_name.startswith(prefix) for prefix in ("/", "$/", ".")
        ):
            return None
        if import_name.startswith(("https://", "http://")):
            return import_name

        library_name = format.format_library_name(import_name)
        if library_name.startswith("@"):
            scope, slash, package_and_path = library_name.partition("/")
            package_name = (
                f"{scope}/{package_and_path.split('/', maxsplit=1)[0]}"
                if slash and package_and_path
                else library_name
            )
        else:
            package_name = library_name.split("/", maxsplit=1)[0]

        if import_name.startswith(f"{library_name}@"):
            version_and_maybe_subpath = import_name[len(library_name) + 1 :]
            version, slash, _ = version_and_maybe_subpath.partition("/")
            if slash and ":" not in version:
                return f"{package_name}@{version}"
            if package_name == library_name:
                return import_name
            return f"{package_name}@{version_and_maybe_subpath}"

        if package_name == library_name:
            return import_name
        return package_name

    def _app_root(self, app_wrappers: dict[tuple[int, str], Component]) -> Component:
        for component in tuple(app_wrappers.values()):
            app_wrappers.update(component._get_all_app_wrap_components())
        order = sorted(app_wrappers, key=operator.itemgetter(0), reverse=True)
        root = copy.deepcopy(app_wrappers[order[0]])

        def reducer(parent: Component, key: tuple[int, str]) -> Component:
            child = copy.deepcopy(app_wrappers[key])
            parent.children.append(child)
            return child

        functools.reduce(
            lambda parent, key: reducer(parent, key),
            order[1:],
            root,
        )
        return root

    def _resolve_hydrate_fallback(self) -> Component | None:
        """Resolve the component shown while the page is hydrating.

        The App-level ``hydrate_fallback`` takes precedence; otherwise the
        ``hydrate_fallback`` config (settable via ``REFLEX_HYDRATE_FALLBACK``)
        is resolved from its dotted import path.

        Error handling differs between the two by design: an App-level callable
        that raises propagates (fail fast, like ``add_page``), since it was
        passed explicitly in code; the config/env path degrades gracefully (logs
        and returns None) as it is ambient deployment configuration.

        Returns:
            The resolved hydrate fallback component, or None if none is configured.
        """
        from reflex.compiler.compiler import into_component

        if self.hydrate_fallback is not None:
            return into_component(self.hydrate_fallback)
        hydrate_fallback_config = get_config().hydrate_fallback
        if hydrate_fallback_config:
            return _component_from_import_path(
                hydrate_fallback_config, "hydrate_fallback"
            )
        return None

    def _should_compile(self) -> bool:
        """Check if the app should be compiled.

        Returns:
            Whether the app should be compiled.
        """
        # Check the environment variable.
        if environment.REFLEX_SKIP_COMPILE.get():
            return False

        nocompile = prerequisites.get_web_dir() / constants.NOCOMPILE_FILE

        # Check the nocompile file.
        if nocompile.exists():
            # Delete the nocompile file
            nocompile.unlink(missing_ok=True)
            return False

        # By default, compile the app.
        return True

    def _setup_sticky_badge(self):
        """Add the sticky badge to the app."""
        from reflex_base.components.memo import memo

        @memo
        def memoized_badge() -> Component:
            sticky_badge = sticky()
            sticky_badge._add_style_recursive({})
            return sticky_badge

        self.app_wraps[0, "StickyBadge"] = lambda _: memoized_badge()

    def _apply_decorated_pages(self):
        """Add @rx.page decorated pages to the app."""
        for render, kwargs in self._registration_context.decorated_pages:
            self.add_page(render, **kwargs)

    def _validate_var_dependencies(self, state: type[BaseState] | None = None) -> None:
        """Validate the dependencies of the vars in the app.

        Args:
            state: The state to validate the dependencies for.

        Raises:
            VarDependencyError: When a computed var has an invalid dependency.
        """
        if not self._state:
            return

        if not state:
            state = self._state

        for var in state.computed_vars.values():
            if not var._cache:
                continue
            deps = var._deps(objclass=state)
            for state_name, dep_set in deps.items():
                state_cls = (
                    state.get_root_state().get_class_substate(state_name)
                    if state_name != state.get_full_name()
                    else state
                )
                for dep in dep_set:
                    if dep not in state_cls.vars and dep not in state_cls.backend_vars:
                        msg = f"ComputedVar {var._name} on state {state.__name__} has an invalid dependency {state_name}.{dep}"
                        raise exceptions.VarDependencyError(msg)

        for substate in state.get_substates():
            self._validate_var_dependencies(substate)

    def _compile(
        self,
        prerender_routes: bool = False,
        dry_run: bool = False,
        use_rich: bool = True,
        trigger: CompileTrigger | None = None,
    ):
        """Compile the app and output it to the pages folder.

        Args:
            prerender_routes: Whether to prerender the routes.
            dry_run: Whether to compile the app without saving it.
            use_rich: Whether to use rich progress bars.
            trigger: Label identifying what initiated this compile. Recorded
                on the ``compile`` telemetry event.

        Raises:
            ReflexRuntimeError: When any page uses state, but no rx.State subclass is defined.
            FileNotFoundError: When a plugin requires a file that does not exist.
        """
        ctx = TelemetryContext.start(trigger=trigger)
        if ctx is None:
            compiler.compile_app(
                self,
                prerender_routes=prerender_routes,
                dry_run=dry_run,
                use_rich=use_rich,
            )
            return

        with ctx:
            did_real_compile = False
            try:
                did_real_compile = compiler.compile_app(
                    self,
                    prerender_routes=prerender_routes,
                    dry_run=dry_run,
                    use_rich=use_rich,
                )
            except Exception as exc:
                ctx.set_exception(exc)
                did_real_compile = True
                raise
            finally:
                if did_real_compile:
                    telemetry_accounting.record_compile(self, ctx)

    def _write_stateful_pages_marker(self):
        """Write list of routes that create dynamic states for the backend to use later."""
        if self._state is not None:
            stateful_pages_marker = (
                prerequisites.get_backend_dir() / constants.Dirs.STATEFUL_PAGES
            )
            stateful_pages_marker.parent.mkdir(parents=True, exist_ok=True)
            with stateful_pages_marker.open("w") as f:
                json.dump(list(self._stateful_pages), f)

    def add_all_routes_endpoint(self):
        """Add an endpoint to the app that returns all the routes."""
        if not self._api:
            return

        def all_routes(_request: Request) -> Response:
            return JSONResponse(list(self._unevaluated_pages.keys()))

        config = get_config()
        self._api.add_route(
            config.prepend_backend_path(str(constants.Endpoint.ALL_ROUTES)),
            all_routes,
            methods=["GET"],
        )

    @overload
    @deprecated("pass token as rx.BaseStateToken instead of str")
    def modify_state(
        self,
        token: str,
        background: bool = False,
        previous_dirty_vars: dict[str, set[str]] | None = None,
    ) -> contextlib.AbstractAsyncContextManager[BaseState]: ...

    @overload
    def modify_state(
        self,
        token: BaseStateToken,
        background: bool = False,
        previous_dirty_vars: dict[str, set[str]] | None = None,
    ) -> contextlib.AbstractAsyncContextManager[BaseState]: ...

    @contextlib.asynccontextmanager
    async def modify_state(
        self,
        token: BaseStateToken | str,
        background: bool = False,
        previous_dirty_vars: dict[str, set[str]] | None = None,
        **context: Unpack[StateModificationContext],
    ) -> AsyncIterator[BaseState]:
        """Modify the state out of band.

        Args:
            token: The token to modify the state for.
            background: Whether the modification is happening in a background task.
            previous_dirty_vars: Vars that are considered dirty from a previous operation.

        Yields:
            The state to modify.

        Raises:
            RuntimeError: If the app has not been initialized yet.
        """
        if self.event_namespace is None:
            msg = "App has not been initialized yet."
            raise RuntimeError(msg)

        if isinstance(token, str):
            token = BaseStateToken.from_legacy_token(token, root_state=self._state)

        # Ensure Reflex contexts are available (e.g. when called from an API route).
        with self.set_contexts(), contextlib.ExitStack() as rebind:
            # Rebind the EventContext to the token being modified so consumers
            # running inside (delta resolution, computed vars) observe this token
            # rather than the event context the caller inherited -- e.g. the
            # shared-state fan-out runs in a task that copied the triggering
            # event's context for a different client. No-op without an EventContext.
            try:
                forked_context = EventContext.get().fork(token=token.ident)
            except LookupError:
                pass
            else:
                reset_token = EventContext.set(forked_context)
                rebind.callback(EventContext.reset, reset_token)
            # Get exclusive access to the state.
            async with self.state_manager.modify_state_with_links(
                token, previous_dirty_vars=previous_dirty_vars, **context
            ) as state:
                # No other event handler can modify the state while in this context.
                yield state
                delta = await state._get_resolved_delta()
                state._clean()
                if delta:
                    # When the frontend vars are modified emit the delta to the frontend.
                    await self.event_namespace.emit_update(
                        update=StateUpdate(delta=delta),
                        token=token.ident,
                    )

    def _validate_exception_handlers(self):
        """Validate the custom event exception handlers for front- and backend.

        Raises:
            ValueError: If the custom exception handlers are invalid.

        """
        frontend_arg_spec = {
            "exception": Exception,
        }

        backend_arg_spec = {
            "exception": Exception,
        }

        for handler_domain, handler_fn, handler_spec in zip(
            ["frontend", "backend"],
            [self.frontend_exception_handler, self.backend_exception_handler],
            [
                frontend_arg_spec,
                backend_arg_spec,
            ],
            strict=True,
        ):
            if hasattr(handler_fn, "__name__"):
                fn_name_ = handler_fn.__name__
            else:
                fn_name_ = type(handler_fn).__name__

            if isinstance(handler_fn, functools.partial):
                msg = f"Provided custom {handler_domain} exception handler `{fn_name_}` is a partial function. Please provide a named function instead."
                raise ValueError(msg)

            if not callable(handler_fn):
                msg = f"Provided custom {handler_domain} exception handler `{fn_name_}` is not a function."
                raise ValueError(msg)

            # Allow named functions only as lambda functions cannot be introspected
            if fn_name_ == "<lambda>":
                msg = f"Provided custom {handler_domain} exception handler `{fn_name_}` is a lambda function. Please use a named function instead."
                raise ValueError(msg)

            # Check if the function has the necessary annotations and types in the right order
            argspec = inspect.getfullargspec(handler_fn)
            arg_annotations = {
                k: eval(v) if isinstance(v, str) else v
                for k, v in argspec.annotations.items()
                if k not in ["args", "kwargs", "return"]
            }

            for required_arg_index, required_arg in enumerate(handler_spec):
                if required_arg not in arg_annotations:
                    msg = f"Provided custom {handler_domain} exception handler `{fn_name_}` does not take the required argument `{required_arg}`"
                    raise ValueError(msg)
                if list(arg_annotations.keys())[required_arg_index] != required_arg:
                    msg = (
                        f"Provided custom {handler_domain} exception handler `{fn_name_}` has the wrong argument order."
                        f"Expected `{required_arg}` as the {required_arg_index + 1} argument but got `{list(arg_annotations.keys())[required_arg_index]}`"
                    )
                    raise ValueError(msg)

                if not issubclass(arg_annotations[required_arg], Exception):
                    msg = (
                        f"Provided custom {handler_domain} exception handler `{fn_name_}` has the wrong type for {required_arg} argument."
                        f"Expected to be `Exception` but got `{arg_annotations[required_arg]}`"
                    )
                    raise ValueError(msg)

            # Check if the return type is valid for backend exception handler
            if handler_domain == "backend":
                sig = inspect.signature(self.backend_exception_handler)
                return_type = (
                    eval(sig.return_annotation)
                    if isinstance(sig.return_annotation, str)
                    else sig.return_annotation
                )

                valid = bool(
                    return_type == EventSpec
                    or return_type == EventSpec | None
                    or return_type == list[EventSpec]
                    or return_type == inspect.Signature.empty
                    or return_type is None
                )

                if not valid:
                    msg = (
                        f"Provided custom {handler_domain} exception handler `{fn_name_}` has the wrong return type."
                        f"Expected `EventSpec | list[EventSpec] | None` but got `{return_type}`"
                    )
                    raise ValueError(msg)


def ping(_request: Request) -> Response:
    """Test API endpoint.

    Args:
        _request: The Starlette request object.

    Returns:
        The response.
    """
    return JSONResponse("pong")


async def health(_request: Request) -> JSONResponse:
    """Health check endpoint to assess the status of the database and Redis services.

    Args:
        _request: The Starlette request object.

    Returns:
        JSONResponse: A JSON object with the health status:
            - "status" (bool): Overall health, True if all checks pass.
            - "db" (bool or str): Database status - True, False, or "NA".
            - "redis" (bool or str): Redis status - True, False, or "NA".
    """
    health_status = {"status": True}
    status_code = 200

    tasks = []

    if prerequisites.check_db_used():
        from reflex.model import get_db_status

        tasks.append(run_in_thread(get_db_status))
    if prerequisites.check_redis_used():
        tasks.append(prerequisites.get_redis_status())

    results = await asyncio.gather(*tasks)

    for result in results:
        health_status |= result

    if "redis" in health_status and health_status["redis"] is None:
        health_status["redis"] = False

    if not all(health_status.values()):
        health_status["status"] = False
        status_code = 503

    return JSONResponse(content=health_status, status_code=status_code)


class EventNamespace(AsyncNamespace):
    """The event namespace."""

    # The application object.
    app: App

    # Maximum error-level log entries a single session may produce via the
    # client_error event before further reports from it are dropped.
    _MAX_CLIENT_ERRORS_PER_SID = 5

    # Process-wide bound on error-level client_error log entries per time
    # window; per-SID budgets alone reset on reconnect, so scripted
    # reconnects could otherwise flood the logs.
    _CLIENT_ERROR_WINDOW_SECONDS = 60.0
    _MAX_CLIENT_ERRORS_PER_WINDOW = 20

    def __init__(self, namespace: str, app: App):
        """Initialize the event namespace.

        Args:
            namespace: The namespace.
            app: The application object.
        """
        super().__init__(namespace)
        self.app = app

        # Use TokenManager for distributed duplicate tab prevention
        self._token_manager = TokenManager.create()

        # Number of client_error reports logged per SID, for rate limiting.
        self._client_error_counts: dict[str, int] = {}

        # Start time and count of the current process-wide client_error window.
        self._client_error_window_start = 0.0
        self._client_error_window_count = 0

    @property
    def token_to_sid(self) -> Mapping[str, str]:
        """Token to SID mapping for backward compatibility.

        Note: this mapping is read-only.

        Returns:
            The token to SID mapping.
        """
        # For backward compatibility, expose the underlying dict
        return self._token_manager.token_to_sid

    @property
    def sid_to_token(self) -> dict[str, str]:
        """SID to token mapping for backward compatibility.

        Returns:
            The SID to token mapping dict.
        """
        # For backward compatibility, expose the underlying dict
        return self._token_manager.sid_to_token

    async def on_connect(self, sid: str, environ: dict):
        """Event for when the websocket is connected.

        Args:
            sid: The Socket.IO session id.
            environ: The request information, including HTTP headers.
        """
        if isinstance(self._token_manager, RedisTokenManager):
            # Make sure this instance is watching for updates from other instances.
            self._token_manager.ensure_lost_and_found_task(self.emit_update)
        query_params = urllib.parse.parse_qs(environ.get("QUERY_STRING", ""))
        token_list = query_params.get("token", [])
        if token_list:
            await self.link_token_to_sid(sid, token_list[0])
        else:
            logger.warning(f"No token provided in connection for session {sid}")

        subprotocol = environ.get("HTTP_SEC_WEBSOCKET_PROTOCOL")
        if subprotocol and subprotocol != constants.Reflex.VERSION:
            logger.warning(
                f"Frontend version {subprotocol} for session {sid} does not match the backend version {constants.Reflex.VERSION}."
            )

    def on_disconnect(self, sid: str) -> asyncio.Task | None:
        """Event for when the websocket disconnects.

        Args:
            sid: The Socket.IO session id.

        Returns:
            An asyncio Task for cleaning up the token, or None.
        """
        self._client_error_counts.pop(sid, None)
        # Get token before cleaning up
        disconnect_token = self.sid_to_token.get(sid)
        if disconnect_token:
            # Use async cleanup through token manager
            task = asyncio.create_task(
                self._token_manager.disconnect_token(disconnect_token, sid),
                name=f"reflex_disconnect_token|{disconnect_token}|{time.time()}",
            )
            # Don't await to avoid blocking disconnect, but handle potential errors
            task.add_done_callback(
                lambda t: (
                    t.exception()
                    and logger.error(f"Token cleanup error: {t.exception()}")
                )
            )
            return task
        return None

    async def emit_update(self, update: StateUpdate, token: str) -> None:
        """Emit an update to the client.

        Args:
            update: The state update to send.
            token: The client token (tab) associated with the event.
        """
        socket_record = self._token_manager.token_to_socket.get(token)
        if (
            socket_record is None
            or socket_record.instance_id != self._token_manager.instance_id
        ):
            if isinstance(self._token_manager, RedisTokenManager):
                # The socket belongs to another instance of the app, send it to the lost and found.
                await self._token_manager.emit_lost_and_found(token, update)
            else:
                # If the socket record is None, we are not connected to a client. Prevent sending
                # updates to all clients.
                logger.warning(
                    f"Attempting to send delta to disconnected client {token!r}"
                )
            return
        # Await the emit directly: wrapping it in a task does not unblock the
        # caller (awaiting the task blocks just the same) and only adds task
        # creation/scheduling overhead on every update.
        await self.emit(str(constants.SocketEvent.EVENT), update, to=socket_record.sid)
        # The emit may complete without suspending (the packet is queued, not
        # sent). Yield one loop tick so the websocket writer can flush the
        # packet before the caller potentially blocks the event loop (e.g. a
        # sync event handler resuming after a yield).
        await asyncio.sleep(0)

    async def on_event(self, sid: str, data: Any):
        """Event for receiving front-end websocket events.

        Args:
            sid: The Socket.IO session id.
            data: The event data.

        Raises:
            RuntimeError: If the Socket.IO is badly initialized.
            EventDeserializationError: If the event data is not a dictionary.
        """
        # Determine the token for this SID
        if (token := self.sid_to_token.get(sid)) is None:
            logger.warning(
                f"Received event from session {sid} with no associated token. This may indicate a bug. Event data: {data}"
            )
            return

        fields = data

        if isinstance(fields, str):
            logger.warning(
                "Received event data as a string. This generally should not happen and may indicate a bug."
                f" Event data: {fields}"
            )
            try:
                fields = json.loads(fields)
            except json.JSONDecodeError as ex:
                msg = f"Failed to deserialize event data: {fields}."
                raise exceptions.EventDeserializationError(msg) from ex

        if not isinstance(fields, dict):
            msg = f"Event data must be a dictionary, but received {fields} of type {type(fields)}."
            raise exceptions.EventDeserializationError(msg)

        try:
            # Get the event.
            event = Event(**{k: v for k, v in fields.items() if k in _EVENT_FIELDS})
        except (TypeError, ValueError) as ex:
            msg = f"Failed to deserialize event data: {fields}."
            raise exceptions.EventDeserializationError(msg) from ex

        # Get the event environment.
        if self.app.sio is None:
            msg = "Socket.IO is not initialized."
            raise RuntimeError(msg)
        environ = self.app.sio.get_environ(sid, self.namespace)
        if environ is None:
            msg = "Socket.IO environ is not initialized."
            raise RuntimeError(msg)

        # Get the client headers.
        headers = {
            k.decode("utf-8"): v.decode("utf-8")
            for (k, v) in environ["asgi.scope"]["headers"]
        }

        # Get the client IP
        try:
            client_ip = environ["asgi.scope"]["client"][0]
            headers["asgi-scope-client"] = client_ip
        except (KeyError, IndexError):
            client_ip = environ.get("REMOTE_ADDR", "0.0.0.0")

        # Unroll reverse proxy forwarded headers.
        client_ip = (
            headers
            .get(
                "x-forwarded-for",
                client_ip,
            )
            .partition(",")[0]
            .strip()
        )
        router_data = event.router_data
        router_data.update({
            constants.RouteVar.QUERY: format.format_query_params(event.router_data),
            constants.RouteVar.CLIENT_TOKEN: token,
            constants.RouteVar.SESSION_ID: sid,
            constants.RouteVar.HEADERS: headers,
            constants.RouteVar.CLIENT_IP: client_ip,
        })
        router_data[constants.RouteVar.PATH] = "/" + (
            self.app.router(path) or "404"
            if (path := router_data.get(constants.RouteVar.PATH))
            else "404"
        ).removeprefix("/")
        await self.app.event_processor.enqueue(token, event)

    async def on_ping(self, sid: str):
        """Event for testing the API endpoint.

        Args:
            sid: The Socket.IO session id.
        """
        # Emit the test event.
        await self.emit(str(constants.SocketEvent.PING), "pong", to=sid)

    async def on_client_error(self, sid: str, data: Any = None):
        """Handle errors reported by the frontend.

        This is a dedicated socket event rather than a state event
        (``FrontendEventExceptionState.handle_frontend_exception``) because a
        state event is addressed by a handler name the frontend derives from
        its own state definitions. When those definitions are what disagree
        with the backend -- the case this handler exists to report -- the name
        may not resolve and the report is lost. A fixed socket event name
        cannot drift, and it still gets through after the frontend has stopped
        sending events on detecting the mismatch.

        Reports are routed through the app's ``frontend_exception_handler``,
        so frontend errors (especially state update processing errors) are
        visible in backend logs and reach custom exception handlers.

        Args:
            sid: The Socket.IO session id.
            data: The error data from the client. Defaults to None because
                python-socketio dispatches a payload-less emit as
                ``on_client_error(sid)``; the malformed-payload guard below
                then drops it without raising.
        """
        if not isinstance(data, dict):
            logger.debug(f"Ignoring malformed client_error payload from SID {sid}.")
            return

        # Check the sender and the rate limits before sanitizing: sanitizing is
        # linear in the size of the client-supplied values, and reports that are
        # dropped here must not cost more than the check itself.
        if sid not in self.sid_to_token:
            # Sockets without a linked token are not known clients; don't let
            # them write error-level entries into the backend logs.
            logger.debug(f"Ignoring client_error report from unknown SID {sid}.")
            return

        # Rate limit per session so a client cannot flood the backend logs.
        error_count = self._client_error_counts.get(sid, 0)
        if error_count >= self._MAX_CLIENT_ERRORS_PER_SID:
            return

        # Also bound total entries per time window: per-SID budgets reset on
        # reconnect, so they alone do not stop scripted reconnect loops.
        now = time.monotonic()
        if now - self._client_error_window_start > self._CLIENT_ERROR_WINDOW_SECONDS:
            self._client_error_window_start = now
            self._client_error_window_count = 0
        if self._client_error_window_count >= self._MAX_CLIENT_ERRORS_PER_WINDOW:
            if self._client_error_window_count == self._MAX_CLIENT_ERRORS_PER_WINDOW:
                # Warn once per window so suppression is visible in the logs
                # and a flooding client cannot silently starve reports from
                # other sessions.
                self._client_error_window_count += 1
                logger.warning(
                    f"Received more than {self._MAX_CLIENT_ERRORS_PER_WINDOW} "
                    f"client_error reports in {self._CLIENT_ERROR_WINDOW_SECONDS:.0f}s; "
                    "suppressing further reports for this window."
                )
            return
        self._client_error_window_count += 1
        self._client_error_counts[sid] = error_count + 1

        error_type = format.sanitize_client_log_value(data.get("error_type", "unknown"))
        if error_type == constants.ClientErrorType.DISPATCH_MISSING:
            substate = format.sanitize_client_log_value(data.get("substate", ""))
            report = (
                f"[SID: {sid}] State update failed: "
                f"no dispatch function for substate(s) '{substate}'. "
                "This indicates a frontend/backend state mismatch. "
                "Rebuild the frontend or check that api_url points to the matching backend."
            )
        else:
            message = format.sanitize_client_log_value(
                data.get("message", "No error message provided")
            )
            report = f"[SID: {sid}] {error_type}: {message}"
        # Route through the app's frontend exception handler so custom
        # handlers (e.g. error trackers) receive client errors too.
        self.app.frontend_exception_handler(Exception(report))

    async def link_token_to_sid(self, sid: str, token: str):
        """Link a token to a session id.

        Args:
            sid: The Socket.IO session id.
            token: The client token.
        """
        # Use TokenManager for duplicate detection and Redis support
        new_token = await self._token_manager.link_token_to_sid(token, sid)

        if new_token:
            # Duplicate detected, emit new token to client
            await self.emit("new_token", new_token, to=sid)

        # Update client state to apply new sid/token for running background tasks.
        if self.app._state is not None:
            async with self.app.state_manager.modify_state(
                BaseStateToken(ident=new_token or token, cls=self.app._state)
            ) as state:
                state.router_data[constants.RouteVar.SESSION_ID] = sid
                state.router = RouterData.from_router_data(state.router_data)
